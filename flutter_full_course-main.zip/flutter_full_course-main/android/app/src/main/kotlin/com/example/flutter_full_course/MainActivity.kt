package com.example.flutter_full_course

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
