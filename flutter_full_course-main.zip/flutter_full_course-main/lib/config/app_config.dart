class AppConfig {
  static const baseUrl = 'http://localhost:8080';
}
